#include <string>

namespace G4INCL {
  const std::string theINCLXXDataFilePath = "/Users/administrateur0/Documents/INCL++/data";
}
