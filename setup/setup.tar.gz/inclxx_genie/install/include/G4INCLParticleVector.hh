#ifndef G4INCLParticleVector_hh
#define G4INCLParticleVector_hh

#include <vector>

namespace G4INCL {
  class Particle;

  typedef std::vector<Particle *> ParticleVector;
}

#endif
