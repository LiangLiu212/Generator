#ifndef G4AblaDataFile_hh
#define G4AblaDataFile_hh 1

#include "G4AblaVirtualData.hh"

/**
 * Read ABLA data from files.
 */
class G4AblaDataFile : public G4AblaVirtualData {

public:
#ifdef ABLAXX_IN_GEANT4_MODE
  G4AblaDataFile();
#else
  G4AblaDataFile(G4INCL::Config *);
#endif
  ~G4AblaDataFile();

  /**
   * Read all data from files.
   */
  bool readData();

private:
  G4int verboseLevel;
#ifndef ABLAXX_IN_GEANT4_MODE
  G4INCL::Config *theConfig;
#endif
};

#endif
