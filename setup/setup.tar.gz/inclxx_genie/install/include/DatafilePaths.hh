#ifndef DATAFILEPATHS_HH
#define DATAFILEPATHS_HH

#include <string>

const std::string defaultINCLXXDatafilePath = "/exp/genie/app/users/liangliu/for_tufts/inclxx_genie/inclxx/data/";
#ifdef INCL_DEEXCITATION_ABLA07
const std::string defaultABLA07DatafilePath = "/exp/genie/app/users/liangliu/for_tufts/inclxx_genie/inclxx/de-excitation/abla07/upstream/tables/";
#endif
#ifdef INCL_DEEXCITATION_ABLAXX
const std::string defaultABLAXXDatafilePath = "/exp/genie/app/users/liangliu/for_tufts/inclxx_genie/inclxx/de-excitation/ablaxx/upstream/data/G4ABLA3.0/";
#endif
#ifdef INCL_DEEXCITATION_ABLACXX
const std::string defaultABLACXXDatafilePath = "/exp/genie/app/users/liangliu/for_tufts/inclxx_genie/inclxx/de-excitation/ablacxx/upstream/data/";
#endif
#ifdef INCL_DEEXCITATION_GEMINIXX
const std::string defaultGEMINIXXDatafilePath = "/exp/genie/app/users/liangliu/for_tufts/inclxx_genie/inclxx/de-excitation/geminixx/upstream/";
#endif

#endif // DATAFILEPATHS_HH
