#ifndef G4ABLARANDOM_HH
#define G4ABLARANDOM_HH

namespace G4AblaRandom {
double flat();
double gaus(double s);
} // namespace G4AblaRandom

#endif
