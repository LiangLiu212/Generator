#ifndef G4INCLDeltaProductionChannel_hh
#define G4INCLDeltaProductionChannel_hh 1

#include "G4INCLParticle.hh"
#include "G4INCLNucleus.hh"
#include "G4INCLIChannel.hh"
#include "G4INCLFinalState.hh"
#include "G4INCLAllocationPool.hh"

namespace G4INCL {
  class DeltaProductionChannel : public IChannel {
  public:
    DeltaProductionChannel(Particle *, Particle *);
    virtual ~DeltaProductionChannel();

    void fillFinalState(FinalState *fs);

  private:
    double sampleDeltaMass(double ecm);

    Particle *particle1, *particle2;

    static const int maxTries;
    INCL_DECLARE_ALLOCATION_POOL(DeltaProductionChannel)
  };
}

#endif
