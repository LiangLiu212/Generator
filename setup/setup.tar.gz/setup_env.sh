source /cvmfs/larsoft.opensciencegrid.org/spack-fnal-v1.0.0/setup-env.sh
spack load gcc/kwnheq5
spack load root
spack load pythia6
spack load log4cpp
spack load lhapdf
spack load libxml2
spack load boost
spack load geant4
spack load gsl
spack load ifdhc
spack load xrootd
spack load cetlib
spack load eigen
export_path(){
  package_env=${1}
  package=${2}
  package_hash=`spack find --loaded --format "{hash}" ${package}`
  export ${package_env}=`spack location -i /${package_hash}`
}


export_path PYTHIA6 pythia6
export_path LOG4CPP log4cpp
export_path LHAPDF6 lhapdf
export_path LIBXML2 libxml2
export_path BOOST boost
export_path GEANT4 geant4
export_path GSL_PATH gsl
export_path GCC_PATH gcc
export_path CETLIB cetlib
export PYTHIA6_LIB_DIR=${PYTHIA6}/lib
#export LHAPDF6=`spack location -i lhapdf`
#export LOG4CPP=`spack location -i log4cpp`
#export LIBXML2=`spack location -i libxml2`
#export BOOST=`spack location -i boost`
#export GEANT4=`spack location -i geant4`
current_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source ${current_dir}/inclxx_genie/install/bin/thisinclxx.sh
echo "Setting GENIE environment variables..."


# Finds the directory where this script is located. This method isn't 
# foolproof. See https://stackoverflow.com/a/246128/4081973 if you need 
# something more robust for edge cases (e.g., you're calling the script using     
# symlinks).
THIS_DIRECTORY="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" 
export GENIEBASE=$THIS_DIRECTORY
export GENIE=$GENIEBASE/Generator
export XSECSPLINEDIR=$GENIEBASE/data
export GENIE_REWEIGHT=$GENIEBASE/Reweight
export PATH=$GENIE/bin:$GENIE_REWEIGHT/bin:$PATH
export LD_LIBRARY_PATH=$GENIE/lib:$GENIE_REWEIGHT/lib:${LOG4CPP}/lib:${PYTHIA6}/lib:${GSL_PATH}/lib:${LHAPDF6}/lib:${LIBXML2}/lib:${BOOST}/lib:${GEANT4}/lib64:${GCC_PATH}/lib64:$LD_LIBRARY_PATH:`root-config --libdir`
#source ${THIS_DIRECTORY}/nusystematics/build/Linux/bin/setup.nusystematics.sh
#source ${THIS_DIRECTORY}/nuisance/build/Linux/setup.sh
export LIBRARY_PATH=${LIBRARY_PATH}:${PYTHIA6_LIB_DIR}
unset GENIEBASE
unset current_dir

