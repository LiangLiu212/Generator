#!/bin/bash

outdir="${1}"
mkdir -p ${outdir}

interaction="CC-INC"

events="50"
version="vINCL"

tune=${outdir}

probe="14"
target="1000060120"
minE="0."
maxE="10."

fluxfile="flux/MCC9_FluxHist_volTPCActive.root"
fluxhisto="hEnumu_cv"

##rm  ${outdir}/*root

spline=${probe}_${target}_${interaction}_${version}_${tune}.xml

# Generate GENIE events
echo "gevgen -n $events -p ${probe} -t ${target} -e 2.0 --event-generator-list ${interaction} --tune ${tune} --cross-sections ${outdir}/${spline}  -o ${outdir}/${probe}_${target}_${interaction}_${version}_${tune}.ghep.root --seed 1232"
exit 0
gevgen -n $events -p ${probe} -t ${target} -e 2.0 --event-generator-list ${interaction} --tune ${tune} --cross-sections ${outdir}/${spline}  -o ${outdir}/${probe}_${target}_${interaction}_${version}_${tune}.ghep.root --seed 1232


# Convert file from ghep to gst
echo "gntpc -f gst -i ${outdir}/${probe}_${target}_${interaction}_${version}_${tune}.ghep.root -o ${outdir}/${probe}_${target}_${interaction}_${version}_${tune}.gst.root --tune ${tune}"
gntpc -f gst -i ${outdir}/${probe}_${target}_${interaction}_${version}_${tune}.ghep.root -o ${outdir}/${probe}_${target}_${interaction}_${version}_${tune}.gst.root --tune ${tune}


rm input-flux.root
