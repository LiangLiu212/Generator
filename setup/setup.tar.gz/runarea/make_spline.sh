#!/bin/bash

outdir="${1}"
mkdir -p ${outdir}

interaction="CC-INC"

events="50000"
version="vINCL"

tune=${outdir}

probe="14"
target="1000060120"
minE="0."
maxE="10."

fluxfile="flux/MCC9_FluxHist_volTPCActive.root"
fluxhisto="hEnumu_cv"

##rm  ${outdir}/*root

spline=${probe}_${target}_${interaction}_${version}_${tune}.xml

# Produce the GENIE splines
echo "gmkspl -p ${probe} -t ${target} -e ${maxE} -o ${outdir}/${spline} --tune ${tune} --event-generator-list ${interaction}"
gmkspl -p ${probe} -t ${target} -e ${maxE} -o ${outdir}/${spline} --tune ${tune} --event-generator-list ${interaction}
exit 0


